<div class="clear"></div>
<div class="clear mt30"></div>
<div id="footer">
		<div class="wrapper">
		
	<p>YOLO SHOP - Technology for life</p>
		</div>
		
</div>