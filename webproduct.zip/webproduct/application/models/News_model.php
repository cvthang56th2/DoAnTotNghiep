<?php
Class News_model extends MY_Model
{
    var $table = 'news';
}