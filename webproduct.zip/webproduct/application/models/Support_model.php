<?php
class Support_model extends MY_Model
{
	//ten bang du lieu
	public $table = 'support';
	
}

