<?php
Class Admin_model extends MY_Model
{
    var $table = 'admin';
    
}