<?php
Class Comment_model extends MY_Model
{
    var $table = 'comment';
}